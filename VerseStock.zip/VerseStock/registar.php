<?php
session_start();
require_once 'database.php';

// Se já estiver logado, redireciona
if (isset($_SESSION['usuario_id'])) {
    header('Location: selecao-empresa.php');
    exit();
}

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['password'] ?? '';
    $confirmar_senha = $_POST['confirmar_password'] ?? '';
    
    // Validações
    if (empty($nome) || empty($email) || empty($senha)) {
        $erro = 'Por favor, preencha todos os campos.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $erro = 'Por favor, introduza um email válido.';
    } elseif (strlen($senha) < 6) {
        $erro = 'A palavra-passe deve ter pelo menos 6 caracteres.';
    } elseif ($senha !== $confirmar_senha) {
        $erro = 'As palavras-passe não coincidem.';
    } else {
        try {
            $db = getDB();
            
            // Verificar se email já existe
            $stmt = $db->prepare("SELECT id FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->fetch()) {
                $erro = 'Este email já está registado.';
            } else {
                // Criar hash da senha
                $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
                
                // Inserir novo usuário
                $stmt = $db->prepare("INSERT INTO usuarios (nome_usuario, email, senha_hash, ativo, criado_em) VALUES (?, ?, ?, 1, NOW())");
                
                if ($stmt->execute([$nome, $email, $senha_hash])) {
                    $sucesso = 'Conta criada com sucesso! Pode fazer login.';
                } else {
                    $erro = 'Erro ao criar conta. Tente novamente.';
                }
            }
            
        } catch (Exception $e) {
            error_log("Erro no registo: " . $e->getMessage());
            $erro = 'Erro ao processar registo. Tente novamente.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registo - Gestão Empresarial</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Mesmos estilos do login */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: #333;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: linear-gradient(135deg, #f5f7fa 0%, #e4edf5 100%);
        }
        
        .register-container {
            display: flex;
            width: 900px;
            background-color: white;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }
        
        .register-left {
            flex: 1;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .register-left h2 {
            font-size: 28px;
            margin-bottom: 15px;
            font-weight: 700;
        }
        
        .register-left p {
            font-size: 16px;
            line-height: 1.6;
            opacity: 0.9;
        }
        
        .register-right {
            flex: 1;
            padding: 50px;
        }
        
        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .logo i {
            font-size: 28px;
            color: #2a5298;
            margin-right: 10px;
        }
        
        .logo h1 {
            font-size: 24px;
            color: #1e3c72;
        }
        
        .register-form h3 {
            font-size: 24px;
            margin-bottom: 8px;
            color: #333;
        }
        
        .register-form p {
            color: #666;
            margin-bottom: 30px;
            font-size: 15px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #444;
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-with-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #777;
        }
        
        .input-with-icon input {
            width: 100%;
            padding: 14px 14px 14px 45px;
            border: 1.5px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .input-with-icon input:focus {
            outline: none;
            border-color: #2a5298;
            box-shadow: 0 0 0 3px rgba(42, 82, 152, 0.1);
        }
        
        .register-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(to right, #1e3c72, #2a5298);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-top: 20px;
        }
        
        .register-btn:hover {
            background: linear-gradient(to right, #2a5298, #3a62a8);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(42, 82, 152, 0.2);
        }
        
        .login-link {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }
        
        .login-link a {
            color: #2a5298;
            text-decoration: none;
            font-weight: 500;
        }
        
        .error-message {
            background-color: #ffebee;
            color: #c62828;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            border-left: 4px solid #c62828;
        }
        
        .success-message {
            background-color: #e8f5e9;
            color: #2e7d32;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            border-left: 4px solid #2e7d32;
        }
        
        @media (max-width: 768px) {
            .register-container {
                flex-direction: column;
                width: 95%;
                margin: 20px;
            }
            
            .register-left, .register-right {
                padding: 30px;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-left">
            <h2>Crie a sua conta</h2>
            <p>Registe-se para começar a utilizar o sistema de gestão empresarial mais completo do mercado.</p>
            <div style="margin-top: 30px;">
                <i class="fas fa-check-circle" style="color: #64b5f6; margin-right: 10px;"></i>
                <span>Grátis para sempre</span><br>
                <i class="fas fa-check-circle" style="color: #64b5f6; margin-right: 10px;"></i>
                <span>Sem limites de utilizadores</span><br>
                <i class="fas fa-check-circle" style="color: #64b5f6; margin-right: 10px;"></i>
                <span>Suporte incluído</span>
            </div>
        </div>
        
        <div class="register-right">
            <div class="logo">
                <i class="fas fa-building"></i>
                <h1>BizManager Pro</h1>
            </div>
            
            <div class="register-form">
                <h3>Criar Conta</h3>
                <p>Preencha os dados para se registar</p>
                
                <?php if (!empty($erro)): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo htmlspecialchars($erro); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($sucesso)): ?>
                    <div class="success-message">
                        <i class="fas fa-check-circle"></i>
                        <?php echo htmlspecialchars($sucesso); ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="nome">Nome completo</label>
                        <div class="input-with-icon">
                            <i class="fas fa-user"></i>
                            <input type="text" id="nome" name="nome" placeholder="O seu nome" required
                                   value="<?php echo isset($_POST['nome']) ? htmlspecialchars($_POST['nome']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">E-mail</label>
                        <div class="input-with-icon">
                            <i class="fas fa-envelope"></i>
                            <input type="email" id="email" name="email" placeholder="seu.email@empresa.pt" required
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Palavra-passe</label>
                        <div class="input-with-icon">
                            <i class="fas fa-lock"></i>
                            <input type="password" id="password" name="password" placeholder="Mínimo 6 caracteres" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirmar_password">Confirmar palavra-passe</label>
                        <div class="input-with-icon">
                            <i class="fas fa-lock"></i>
                            <input type="password" id="confirmar_password" name="confirmar_password" placeholder="Repita a palavra-passe" required>
                        </div>
                    </div>
                    
                    <button type="submit" class="register-btn">
                        <i class="fas fa-user-plus"></i> Criar Conta
                    </button>
                    
                    <div class="login-link">
                        Já tem conta? <a href="login.php">Iniciar sessão</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>