<?php
session_start();
require_once 'database.php';

// Se já estiver logado, redireciona para seleção de empresa
if (isset($_SESSION['usuario_id'])) {
    header('Location: selecao-empresa.php');
    exit();
}

$erro = '';

// Processar login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['password'] ?? '';
    $lembrar = isset($_POST['remember']);
    
    if (empty($email) || empty($senha)) {
        $erro = 'Por favor, preencha todos os campos.';
    } else {
        try {
            $db = getDB();
            
            // Buscar usuário por email
            $stmt = $db->prepare("SELECT id, nome_usuario, email, senha_hash, ativo FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Verificar se usuário existe e está ativo
            if ($usuario && $usuario['ativo'] == 1) {
                // Verificar senha
                if (password_verify($senha, $usuario['senha_hash'])) {
                    // Login bem-sucedido
                    $_SESSION['usuario_id'] = $usuario['id'];
                    $_SESSION['usuario_nome'] = $usuario['nome_usuario'];
                    $_SESSION['usuario_email'] = $usuario['email'];
                    $_SESSION['login_time'] = time();
                    
                    // Se "Lembrar-me" estiver marcado, criar cookie (30 dias)
                    if ($lembrar) {
                        $token = bin2hex(random_bytes(32));
                        $expira = time() + (30 * 24 * 60 * 60); // 30 dias
                        
                        // Guardar token na base de dados (é preciso adicionar coluna)
                        // Por enquanto, apenas comentado até adicionar a coluna
                        /*
                        $stmt = $db->prepare("UPDATE usuarios SET remember_token = ? WHERE id = ?");
                        $stmt->execute([$token, $usuario['id']]);
                        setcookie('remember_token', $token, $expira, '/', '', false, true);
                        */
                    }
                    
                    // Redirecionar para seleção de empresa
                    header('Location: selecao-empresa.php');
                    exit();
                } else {
                    $erro = 'Email ou palavra-passe inválidos.';
                }
            } else {
                $erro = 'Email ou palavra-passe inválidos.';
            }
            
        } catch (Exception $e) {
            error_log("Erro no login: " . $e->getMessage());
            $erro = 'Erro ao processar login. Tente novamente.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Gestão Empresarial</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            color: #333;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: linear-gradient(135deg, #f5f7fa 0%, #e4edf5 100%);
        }
        
        .login-container {
            display: flex;
            width: 900px;
            height: 550px;
            background-color: white;
            border-radius: 16px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
            overflow: hidden;
        }
        
        .login-left {
            flex: 1;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 50px 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .login-left h2 {
            font-size: 28px;
            margin-bottom: 15px;
            font-weight: 700;
        }
        
        .login-left p {
            font-size: 16px;
            line-height: 1.6;
            opacity: 0.9;
            margin-bottom: 30px;
        }
        
        .features {
            margin-top: 30px;
        }
        
        .feature {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .feature i {
            font-size: 20px;
            margin-right: 15px;
            color: #64b5f6;
        }
        
        .login-right {
            flex: 1;
            padding: 60px 50px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .logo {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
        }
        
        .logo i {
            font-size: 28px;
            color: #2a5298;
            margin-right: 10px;
        }
        
        .logo h1 {
            font-size: 24px;
            color: #1e3c72;
        }
        
        .login-form h3 {
            font-size: 24px;
            margin-bottom: 8px;
            color: #333;
        }
        
        .login-form p {
            color: #666;
            margin-bottom: 30px;
            font-size: 15px;
        }
        
        .form-group {
            margin-bottom: 22px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #444;
        }
        
        .input-with-icon {
            position: relative;
        }
        
        .input-with-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #777;
        }
        
        .input-with-icon input {
            width: 100%;
            padding: 14px 14px 14px 45px;
            border: 1.5px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        .input-with-icon input:focus {
            outline: none;
            border-color: #2a5298;
            box-shadow: 0 0 0 3px rgba(42, 82, 152, 0.1);
        }
        
        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            font-size: 14px;
        }
        
        .remember {
            display: flex;
            align-items: center;
        }
        
        .remember input {
            margin-right: 8px;
        }
        
        .forgot-link {
            color: #2a5298;
            text-decoration: none;
            font-weight: 500;
        }
        
        .login-btn {
            width: 100%;
            padding: 15px;
            background: linear-gradient(to right, #1e3c72, #2a5298);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            margin-bottom: 20px;
        }
        
        .login-btn:hover {
            background: linear-gradient(to right, #2a5298, #3a62a8);
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(42, 82, 152, 0.2);
        }
        
        .test-login {
            background-color: #f0f7ff;
            border: 1px dashed #2a5298;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        .test-login p {
            font-size: 14px;
            color: #555;
            margin-bottom: 10px;
        }
        
        .test-credentials {
            display: flex;
            justify-content: space-between;
            font-size: 13px;
        }
        
        .test-credentials div {
            background-color: #e4edf5;
            padding: 8px 12px;
            border-radius: 5px;
        }
        
        .footer {
            text-align: center;
            margin-top: 30px;
            color: #777;
            font-size: 13px;
        }
        
        .register-link {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
        
        .register-link a {
            color: #2a5298;
            text-decoration: none;
            font-weight: 500;
        }
        
        .register-link a:hover {
            text-decoration: underline;
        }
        
        .error-message {
            background-color: #ffebee;
            color: #c62828;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            border-left: 4px solid #c62828;
        }
        
        .loading-spinner {
            display: none;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255, 255, 255, 0.3);
            border-radius: 50%;
            border-top-color: white;
            animation: spin 1s ease-in-out infinite;
            margin-right: 10px;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        
        .login-btn.loading .loading-spinner {
            display: inline-block;
        }
        
        .login-btn.loading span {
            display: none;
        }
        
        @media (max-width: 950px) {
            .login-container {
                width: 95%;
                height: auto;
                margin: 20px;
            }
        }
        
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
                height: auto;
            }
            
            .login-left, .login-right {
                padding: 40px 30px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-left">
            <h2>Sistema de Gestão Empresarial</h2>
            <p>Uma solução completa para administrar a sua empresa, controlar inventário e otimizar processos operacionais.</p>
            
            <div class="features">
                <div class="feature">
                    <i class="fas fa-boxes"></i>
                    <div>
                        <h4>Gestão de Stock</h4>
                        <p>Controle o seu inventário em tempo real</p>
                    </div>
                </div>
                <div class="feature">
                    <i class="fas fa-chart-line"></i>
                    <div>
                        <h4>Relatórios Detalhados</h4>
                        <p>Analise o desempenho da sua empresa</p>
                    </div>
                </div>
                <div class="feature">
                    <i class="fas fa-cogs"></i>
                    <div>
                        <h4>Configuração Flexível</h4>
                        <p>Personalize de acordo com as necessidades do seu negócio</p>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="login-right">
            <div class="logo">
                <i class="fas fa-building"></i>
                <h1>BizManager Pro</h1>
            </div>
            
            <div class="login-form">
                <h3>Iniciar Sessão</h3>
                <p>Introduza as suas credenciais para aceder ao sistema</p>
                
                <?php if (!empty($erro)): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-circle"></i>
                        <?php echo htmlspecialchars($erro); ?>
                    </div>
                <?php endif; ?>
                
                <form id="loginForm" method="POST" action="">
                    <div class="form-group">
                        <label for="email">E-mail</label>
                        <div class="input-with-icon">
                            <i class="fas fa-envelope"></i>
                            <input type="email" id="email" name="email" placeholder="seu.email@empresa.pt" 
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">Palavra-passe</label>
                        <div class="input-with-icon">
                            <i class="fas fa-lock"></i>
                            <input type="password" id="password" name="password" placeholder="Introduza a sua palavra-passe" required>
                        </div>
                    </div>
                    
                    <div class="remember-forgot">
                        <div class="remember">
                            <input type="checkbox" id="remember" name="remember">
                            <label for="remember">Lembrar-me</label>
                        </div>
                        <a href="#" class="forgot-link" id="forgotLink">Esqueceu a palavra-passe?</a>
                    </div>
                    
                    <button type="submit" class="login-btn" id="loginButton">
                        <div class="loading-spinner"></div>
                        <span><i class="fas fa-sign-in-alt"></i> Iniciar Sessão</span>
                    </button>
                    
                    <div class="register-link">
                        Não tem conta? <a href="registar.php" id="registerLink">Criar nova conta</a>
                    </div>
                </form>
                
                <div class="footer">
                    <p>© 2025 BizManager Pro. Todos os direitos reservados.</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loginForm = document.getElementById('loginForm');
            const loginButton = document.getElementById('loginButton');
            
            // Manipular o envio do formulário de login
            loginForm.addEventListener('submit', function(e) {
                loginButton.classList.add('loading');
                // O formulário será submetido normalmente para processamento PHP
            });
        });
    </script>
</body>
</html>