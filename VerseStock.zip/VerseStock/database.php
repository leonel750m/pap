<?php
// database.php
class Database {
    private $host = 'localhost';
    private $db_name = 'verse_stock';
    private $username = 'root'; // Altere conforme sua configuração
    private $password = ''; // Altere conforme sua configuração
    private $conn;

    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("SET NAMES utf8mb4");
        } catch(PDOException $e) {
            echo "Erro na conexão: " . $e->getMessage();
        }

        return $this->conn;
    }
}

// Função auxiliar para obter conexão
function getDB() {
    $database = new Database();
    return $database->getConnection();
}
?>