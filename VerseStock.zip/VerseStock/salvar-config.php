<?php
session_start();
require_once 'database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: selecao-empresa.php');
    exit();
}

try {
    $db = getDB();
    
    // Validar dados recebidos
    $sistema_tipo = $_POST['sistema_tipo'] ?? '';
    $empresa_nome = $_POST['empresa_nome'] ?? '';
    $empresa_setor = $_POST['empresa_setor'] ?? '';
    $empresa_dimensao = $_POST['empresa_dimensao'] ?? '';
    $armazens_qtd = (int)($_POST['armazens_qtd'] ?? 1);
    $relatorios_frequencia = $_POST['relatorios_frequencia'] ?? 'semanal';
    $empresa_email = $_POST['empresa_email'] ?? '';
    $empresa_telefone = $_POST['empresa_telefone'] ?? '';
    $modulos_selecionados = isset($_POST['modulos']) ? implode(',', $_POST['modulos']) : '';

    // Iniciar transação
    $db->beginTransaction();

    // 1. Inserir dados da empresa na tabela clientes (como empresa principal)
    $stmt = $db->prepare("
        INSERT INTO clientes (nome, email, telefone, numero_contribuinte) 
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$empresa_nome, $empresa_email, $empresa_telefone, 'EMPRESA_PRINCIPAL']);
    $cliente_id = $db->lastInsertId();

    // 2. Criar armazéns conforme quantidade especificada
    for ($i = 1; $i <= $armazens_qtd; $i++) {
        $stmt = $db->prepare("INSERT INTO armazens (nome, localizacao) VALUES (?, ?)");
        $stmt->execute([
            "Armazém {$i}",
            "Localização padrão"
        ]);
    }

    // 3. Criar categorias básicas baseadas no tipo de sistema
    $categorias_padrao = [
        'metal' => ['Matéria-Prima', 'Produtos Acabados', 'Ligas Metálicas', 'Componentes'],
        'construction' => ['Materiais Básicos', 'Ferramentas', 'Equipamentos', 'Acabamentos'],
        'retail' => ['Eletrônicos', 'Vestuário', 'Alimentos', 'Utilidades'],
        'logistics' => ['Paletes', 'Caixas', 'Contentores', 'Embalagens']
    ];

    $categorias = $categorias_padrao[$sistema_tipo] ?? ['Geral', 'Específico', 'Diversos'];
    
    foreach ($categorias as $categoria) {
        $stmt = $db->prepare("INSERT INTO categorias (nome) VALUES (?)");
        $stmt->execute([$categoria]);
    }

    // 4. Criar departamentos padrão
    $departamentos = ['Administração', 'Vendas', 'Compras', 'Armazém', 'Recursos Humanos'];
    foreach ($departamentos as $dept) {
        $stmt = $db->prepare("INSERT INTO departamentos (nome, descricao) VALUES (?, ?)");
        $stmt->execute([$dept, "Departamento de {$dept}"]);
    }

    // 5. Criar cargos padrão
    $cargos = ['Diretor', 'Gerente', 'Supervisor', 'Operador', 'Assistente'];
    foreach ($cargos as $cargo) {
        $stmt = $db->prepare("INSERT INTO cargos (nome, descricao) VALUES (?, ?)");
        $stmt->execute([$cargo, "Cargo de {$cargo}"]);
    }

    // 6. Inserir produtos de exemplo
    for ($i = 1; $i <= 10; $i++) {
        $stmt = $db->prepare("
            INSERT INTO produtos (nome, descricao, categoria_id, preco_unitario, estoque_minimo, ativo) 
            VALUES (?, ?, 1, ?, 10, 1)
        ");
        $stmt->execute([
            "Produto Exemplo {$i}",
            "Descrição do produto exemplo {$i}",
            rand(10, 1000) / 10
        ]);
    }

    // 7. Inserir fornecedores de exemplo
    for ($i = 1; $i <= 5; $i++) {
        $stmt = $db->prepare("
            INSERT INTO fornecedores (nome, email, telefone, numero_contribuinte) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            "Fornecedor {$i}",
            "fornecedor{$i}@exemplo.pt",
            "+351 999 999 99{$i}",
            "99999999{$i}"
        ]);
    }

    // 8. Guardar configuração na sessão
    $config = [
        'empresa_nome' => $empresa_nome,
        'empresa_setor' => $empresa_setor,
        'empresa_dimensao' => $empresa_dimensao,
        'sistema_tipo' => $sistema_tipo,
        'armazens_qtd' => $armazens_qtd,
        'relatorios_frequencia' => $relatorios_frequencia,
        'empresa_email' => $empresa_email,
        'empresa_telefone' => $empresa_telefone,
        'modulos_selecionados' => isset($_POST['modulos']) ? $_POST['modulos'] : [],
        'data_configuracao' => date('Y-m-d H:i:s'),
        'cliente_id' => $cliente_id
    ];

    $_SESSION['config_sistema'] = $config;
    $_SESSION['sistema_configurado'] = true;
    $_SESSION['empresa_id'] = $cliente_id;

    // Commit da transação
    $db->commit();

    // Redirecionar para o dashboard
    header('Location: dashboard.php');
    exit();

} catch (Exception $e) {
    // Rollback em caso de erro
    if (isset($db)) {
        $db->rollBack();
    }
    
    // Registrar erro
    error_log("Erro na configuração: " . $e->getMessage());
    
    // Mostrar mensagem de erro amigável
    echo "<!DOCTYPE html>
    <html>
    <head>
        <title>Erro na Configuração</title>
        <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'>
        <style>
            body { font-family: 'Segoe UI', sans-serif; background: #f5f7fa; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
            .error-box { background: white; padding: 40px; border-radius: 16px; box-shadow: 0 12px 30px rgba(0,0,0,0.08); text-align: center; max-width: 500px; }
            .error-icon { font-size: 64px; color: #f46b45; margin-bottom: 20px; }
            h2 { color: #1e3c72; margin-bottom: 15px; }
            p { color: #666; margin-bottom: 25px; line-height: 1.6; }
            .btn { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); color: white; padding: 12px 30px; border: none; border-radius: 8px; cursor: pointer; text-decoration: none; display: inline-block; }
        </style>
    </head>
    <body>
        <div class='error-box'>
            <div class='error-icon'><i class='fas fa-exclamation-triangle'></i></div>
            <h2>Erro na Configuração</h2>
            <p>Ocorreu um erro ao configurar o sistema. Por favor, tente novamente.</p>
            <a href='selecao-empresa.php' class='btn'><i class='fas fa-arrow-left'></i> Voltar</a>
        </div>
    </body>
    </html>";
    exit();
}
?>