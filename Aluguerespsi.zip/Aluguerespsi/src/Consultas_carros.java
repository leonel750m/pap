import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Consultas_carros {
    private conexão conexao;
    
    // CORREÇÃO: O construtor deve ter o mesmo nome da classe
    public Consultas_carros() {
        conexao = new conexão();
    }
    
    // ========== CONSULTAS DE CARROS ==========
    
    // 1. Todos os carros
    public List<String[]> getAllCarros() {
        List<String[]> carros = new ArrayList<>();
        String sql = "SELECT id, marca, modelo, cor, matricula, ano, nlugares, preco_diario, " +
                    "CASE disponivel WHEN 1 THEN 'Disponível' ELSE 'Indisponível' END as disponibilidade " +
                    "FROM carros ORDER BY marca, modelo";
        
        try (Connection conn = conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                String[] carro = new String[9];
                carro[0] = String.valueOf(rs.getInt("id"));
                carro[1] = rs.getString("marca");
                carro[2] = rs.getString("modelo");
                carro[3] = rs.getString("cor");
                carro[4] = rs.getString("matricula");
                carro[5] = String.valueOf(rs.getInt("ano"));
                carro[6] = String.valueOf(rs.getInt("nlugares"));
                carro[7] = String.valueOf(rs.getDouble("preco_diario"));
                carro[8] = rs.getString("disponibilidade");
                carros.add(carro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            conexao.closeConnection();
        }
        return carros;
    }
    
    // 2. Carros por marca
    public List<String[]> getCarrosByMarca(String marca) {
        List<String[]> carros = new ArrayList<>();
        String sql = "SELECT id, marca, modelo, cor, matricula, ano, nlugares, preco_diario, " +
                    "CASE disponivel WHEN 1 THEN 'Disponível' ELSE 'Indisponível' END as disponibilidade " +
                    "FROM carros WHERE marca LIKE ? ORDER BY modelo";
        
        try (Connection conn = conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, "%" + marca + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                String[] carro = new String[9];
                carro[0] = String.valueOf(rs.getInt("id"));
                carro[1] = rs.getString("marca");
                carro[2] = rs.getString("modelo");
                carro[3] = rs.getString("cor");
                carro[4] = rs.getString("matricula");
                carro[5] = String.valueOf(rs.getInt("ano"));
                carro[6] = String.valueOf(rs.getInt("nlugares"));
                carro[7] = String.valueOf(rs.getDouble("preco_diario"));
                carro[8] = rs.getString("disponibilidade");
                carros.add(carro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            conexao.closeConnection();
        }
        return carros;
    }
    
    // 3. Carros por cor
    public List<String[]> getCarrosByCor(String cor) {
        List<String[]> carros = new ArrayList<>();
        String sql = "SELECT id, marca, modelo, cor, matricula, ano, nlugares, preco_diario, " +
                    "CASE disponivel WHEN 1 THEN 'Disponível' ELSE 'Indisponível' END as disponibilidade " +
                    "FROM carros WHERE cor LIKE ? ORDER BY marca, modelo";
        
        try (Connection conn = conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, "%" + cor + "%");
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                String[] carro = new String[9];
                carro[0] = String.valueOf(rs.getInt("id"));
                carro[1] = rs.getString("marca");
                carro[2] = rs.getString("modelo");
                carro[3] = rs.getString("cor");
                carro[4] = rs.getString("matricula");
                carro[5] = String.valueOf(rs.getInt("ano"));
                carro[6] = String.valueOf(rs.getInt("nlugares"));
                carro[7] = String.valueOf(rs.getDouble("preco_diario"));
                carro[8] = rs.getString("disponibilidade");
                carros.add(carro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            conexao.closeConnection();
        }
        return carros;
    }
    
    // 4. Carros disponíveis
    public List<String[]> getCarrosDisponiveis() {
        List<String[]> carros = new ArrayList<>();
        String sql = "SELECT id, marca, modelo, cor, matricula, ano, nlugares, preco_diario " +
                    "FROM carros WHERE disponivel = 1 ORDER BY marca, modelo";
        
        try (Connection conn = conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            
            while (rs.next()) {
                String[] carro = new String[8];
                carro[0] = String.valueOf(rs.getInt("id"));
                carro[1] = rs.getString("marca");
                carro[2] = rs.getString("modelo");
                carro[3] = rs.getString("cor");
                carro[4] = rs.getString("matricula");
                carro[5] = String.valueOf(rs.getInt("ano"));
                carro[6] = String.valueOf(rs.getInt("nlugares"));
                carro[7] = String.valueOf(rs.getDouble("preco_diario"));
                carros.add(carro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            conexao.closeConnection();
        }
        return carros;
    }
    
    // 5. Método auxiliar para formatar resultados como string
    public String formatarTodosCarros() {
        List<String[]> carros = getAllCarros();
        StringBuilder sb = new StringBuilder();
        
        sb.append("=== TODOS OS CARROS ===\n\n");
        if (carros.isEmpty()) {
            sb.append("Nenhum carro encontrado.\n");
        } else {
            sb.append(String.format("%-5s %-15s %-15s %-10s %-10s %-6s %-8s %-10s %-15s\n",
                "ID", "Marca", "Modelo", "Cor", "Matrícula", "Ano", "Lugares", "Preço/Dia", "Disponível"));
            sb.append("----------------------------------------------------------------------------------------\n");
            
            for (String[] carro : carros) {
                sb.append(String.format("%-5s %-15s %-15s %-10s %-10s %-6s %-8s %-10s %-15s\n",
                    carro[0], carro[1], carro[2], carro[3], carro[4], carro[5], carro[6], carro[7], carro[8]));
            }
            sb.append("\nTotal: ").append(carros.size()).append(" carros encontrados.\n");
        }
        return sb.toString();
    }
}