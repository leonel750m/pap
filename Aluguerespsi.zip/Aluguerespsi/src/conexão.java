import java.sql.*;
import javax.swing.JOptionPane;

public class conexão {
    private Connection conn;
    
    public Connection getConnection() {
        try {
            String url = "jdbc:mysql://localhost:3306/aluguueres";
            String user = "root";
            String password = "";
            conn = DriverManager.getConnection(url, user, password);
            return conn;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    public void closeConnection() {
        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // ========== MÉTODO DE TESTE ==========
    public static boolean testarConexao() {
        System.out.println("🔍 Testando conexão MySQL...");
        
        conexão con = new conexão();
        Connection conn = con.getConnection();
        
        if (conn != null) {
            try {
                // Verificar si realmente funciona
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("SELECT 1");
                rs.close();
                stmt.close();
                
                con.closeConnection();
                System.out.println("✅ Teste: OK");
                return true;
            } catch (SQLException e) {
                System.out.println("❌ Teste falhou após conectar: " + e.getMessage());
                return false;
            }
        } else {
            System.out.println("❌ Teste: FALHA");
            return false;
        }
    }
    
    // ========== TESTE COM MENSAGEM ==========
    public static void testarEMostrarMensagem() {
        if (testarConexao()) {
            JOptionPane.showMessageDialog(null,
                "✅ Conexão estabelecida com sucesso!\n" +
                "Banco: alugueres\n" +
                "Status: PRONTO PARA USO",
                "Conexão OK", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null,
                "❌ FALHA NA CONEXÃO!\n\n" +
                "Verifique:\n" +
                "1. ✅ MySQL está rodando? (XAMPP/WAMP)\n" +
                "2. ✅ Banco 'alugueres' existe?\n" +
                "3. ✅ Usuário: root / Senha: [vazia]\n" +
                "4. ✅ Driver MySQL instalado no projeto",
                "Erro de Conexão", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // ========== TESTE DETALHADO ==========
    public static void testarDetalhado() {
        conexão con = new conexão();
        Connection conn = con.getConnection();
        
        if (conn != null) {
            try {
                DatabaseMetaData meta = conn.getMetaData();
                
                String info = "✅ CONEXÃO ESTABELECIDA\n\n";
                info += "📊 Informações:\n";
                info += "• MySQL Version: " + meta.getDatabaseProductVersion() + "\n";
                info += "• Driver: " + meta.getDriverName() + "\n";
                info += "• URL: " + meta.getURL() + "\n";
                info += "• Usuário: " + meta.getUserName() + "\n";
                
                // Verificar tabelas
                ResultSet tables = meta.getTables("alugueres", null, "%", null);
                int tabelasCount = 0;
                String tabelas = "";
                
                while (tables.next()) {
                    tabelasCount++;
                    tabelas += "   - " + tables.getString("TABLE_NAME") + "\n";
                }
                
                info += "\n📁 Base 'alugueres':\n";
                info += "• Tabelas encontradas: " + tabelasCount + "\n";
                if (tabelasCount > 0) {
                    info += tabelas;
                }
                
                JOptionPane.showMessageDialog(null, info, "Teste Detalhado", JOptionPane.INFORMATION_MESSAGE);
                
                tables.close();
                con.closeConnection();
                
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,
                    "Erro ao obter informações: " + e.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null,
                "❌ Não foi possível conectar",
                "Falha", JOptionPane.ERROR_MESSAGE);
        }
    }
}